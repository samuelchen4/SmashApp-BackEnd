const dbConfig = {
  database: 'smashcityDb',
  host: 'aws-simplified.cvlzcxvilm37.us-west-2.rds.amazonaws.com',
  port: '3306',
  user: 'admin',
  password: 'smashcity888',
};

module.exports = dbConfig;
